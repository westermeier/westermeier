fileInput = document.getElementById("fileInput");
const imgs = document.querySelectorAll(".img");

if (localStorage.getItem("length") != null) {
    length = localStorage.getItem("length");
}
else {
    localStorage.setItem("length", 0);
    window.location = "";
}

var s = "";
for (let index = 0; index < 10; index++) {
    s += "0";
    if (localStorage.getItem("bild" + s) != null) {
        document.getElementById("content").innerHTML += '<img class="img" src="' + localStorage.getItem("bild" + s) + '" onclick="big(' + index + ')" frameborder="0"></img><br>'
    }
}

fileInput.addEventListener("change", e => {
    const file = fileInput.files[0];
    const reader = new FileReader();

    reader.addEventListener("load", () => {
        timeToUpload.innerText = "nochnicht Upgeloaden";
        try {
            localStorage.setItem("length", length + "0")
            NewItem("bild" + length, reader.result);
        } catch (error) {
            alert(error)
        }
        timeToUpload.innerText = "Upgeloaden"
        window.location = "";
    })

    reader.readAsDataURL(file);
});

function NewItem(key, content) {
    localStorage.setItem(key, content);
}

function big(i) {
    source = document.querySelectorAll(".img")[i].src;
    document.body.innerHTML += '<img id="bigImage" style="display: none;" src="' + source + '">';
    document.body.innerHTML += '<div style="background: black;position: fixed;width: 100%;height: 100vh;top:0;right:0;"</div>';
    if (document.getElementById("bigImage").naturalWidth > document.getElementById("bigImage").naturalHeight) {
        document.body.innerHTML += '<img style="width: 100%; position: fixed;top: 0;left: 0;" src="' + source + '"></img>';
    }
    if (document.getElementById("bigImage").naturalWidth < document.getElementById("bigImage").naturalHeight) {
        document.body.innerHTML += '<img style="height: 100vh; position: fixed;top: 0;left: 0;" src="' + source + '"></img>';
    }
    
    if (document.getElementById("bigImage").naturalWidth == document.getElementById("bigImage").naturalHeight) {
        document.body.innerHTML += '<img style="width: 100vmin; position: fixed;top: 0;left: 0;" src="' + source + '"></img>';
    }
}

function deleteI() {
    var c = prompt("Do You Want To Delete All? (y)");
    if (c == "y") {
        localStorage.clear();
    }
    window.location = "";
}